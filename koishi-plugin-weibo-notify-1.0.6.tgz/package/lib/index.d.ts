import { Context, Logger } from 'koishi';
import type { Config as PluginConfig } from './services/config';
export { Config } from './services/config';
export declare const name = "weibo-notify";
export declare const logger: Logger;
export declare const using: string[];
export declare const inject: {
    required: string[];
    optional: string[];
};
declare module 'koishi' {
    interface Tables {
        weibo_cookies: WeiboCookie;
    }
}
export interface WeiboCookie {
    name: string;
    value: string;
    domain: string;
    updatedAt: Date;
}
export declare function apply(ctx: Context, config: PluginConfig): void;
