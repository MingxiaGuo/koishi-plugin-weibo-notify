export declare function getWeibo(config: any, callback?: any, retry?: boolean): Promise<any>;
