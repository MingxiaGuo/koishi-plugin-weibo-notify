import type { Context, Logger } from 'koishi';
import type { Config as PluginConfig } from './config';
export declare const ACCOUNT_API_PREFIX = "/weibo-notify/api";
export declare const ACCOUNT_LOGIN_URL = "https://passport.weibo.com/";
export interface WeiboProfile {
    screenName: string | null;
    avatarUrl: string | null;
    uid: string | null;
}
export interface LoginPanelState {
    status: 'idle' | 'pending' | 'success' | 'error';
    message: string;
    lastError: string | null;
    hasCookie: boolean;
    cookieStatusText: string;
    autoLoginEnabled: boolean;
    qrImageDataUrl: string | null;
    cookieFile: string;
    lastQrUpdatedAt: number | null;
    lastCookieRefreshAt: number | null;
    loginUrl: string;
    profile: WeiboProfile | null;
}
export declare function applyAccountService(ctx: Context, config: PluginConfig, logger: Logger): Promise<void>;
