import { Context } from 'koishi';
export declare function getWeiboAndSendMessageToGroup(ctx: Context, params: any): Promise<void>;
