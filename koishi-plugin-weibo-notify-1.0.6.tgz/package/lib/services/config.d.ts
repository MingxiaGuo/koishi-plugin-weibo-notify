import { Schema } from 'koishi';
export interface SubscriptionItem {
    weiboUID: string;
    forward: boolean;
    blockwords: string;
    keywords: string;
    groupID: string;
    sendAll: boolean;
    sub_showScreenshot: boolean;
}
export interface Config {
    basic: {
        account: string;
        platform: string;
        waitMinutes: number;
        cookieRefreshIntervalHours: number;
    };
    subs: SubscriptionItem[];
}
export declare const Config: Schema<Config>;
