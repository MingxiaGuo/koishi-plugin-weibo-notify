export declare function to<T, U = Error>(promise: Promise<T>, errorExt?: object): Promise<[U, undefined] | [null, T]>;
export declare function parseDateString(dateString: string): Date;
export declare function checkWords(params: any, message: string): boolean;
export declare function stripHtmlTags(html: string): string;
