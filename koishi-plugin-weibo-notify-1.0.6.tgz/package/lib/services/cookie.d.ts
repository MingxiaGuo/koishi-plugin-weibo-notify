export declare function setCookie(cookie: string | null): void;
export declare function getCookie(): string | null;
export declare function setUserAgent(userAgent: string | null): void;
export declare function getUserAgent(): string | null;
export declare function getRandomUserAgent(): string;
export declare function setCookieUpdater(updater: (() => Promise<string | null>) | null): void;
export declare function extractXSRFToken(cookie: string | null): string;
export declare function fetchCookie(): Promise<string>;
export declare function refreshCookie(): Promise<string | null>;
type AnyCookie = any;
export interface CookieResult {
    cookieString: string;
    cookies: AnyCookie[];
    qrImageDataUrl?: string;
    qrDetected?: boolean;
}
export declare function saveCookiesToDatabase(ctx: any, cookies: AnyCookie[]): Promise<void>;
export declare function loadCookiesFromDatabase(ctx: any): Promise<AnyCookie[] | null>;
export declare function loadCookieStringFromDatabase(ctx: any): Promise<string | null>;
export interface QrLoginOptions {
    timeoutMs?: number;
    onPageCreated?: (page: any) => void | Promise<void>;
    onQrCaptured?: (dataUrl: string | null) => void | Promise<void>;
}
export declare function captureQrFromPage(page: any, timeoutMs?: number): Promise<{
    dataUrl: string | null;
    detected: boolean;
}>;
export declare function loginWithQrViaService(ctx: any, opts?: QrLoginOptions): Promise<CookieResult>;
/**
 * 静默打开微博主页，利用已有的 Cookie 自动续期
 */
export declare function renewCookiesViaService(ctx: any, existingCookies: AnyCookie[]): Promise<CookieResult>;
export {};
