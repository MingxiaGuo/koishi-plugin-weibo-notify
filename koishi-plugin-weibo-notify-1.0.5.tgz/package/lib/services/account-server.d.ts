import type { Context, Logger } from 'koishi';
import type { Config as PluginConfig } from './config';
export declare function applyAccountService(ctx: Context, config: PluginConfig, logger: Logger): Promise<void>;
