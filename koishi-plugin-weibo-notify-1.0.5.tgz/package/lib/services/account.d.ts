export declare const ACCOUNT_API_PREFIX = "/weibo-notify/api";
export declare const ACCOUNT_LOGIN_URL = "https://passport.weibo.com/";
export declare const ACCOUNT_SCHEMA_ROLE = "weibo-login-panel";
export interface WeiboProfile {
    screenName: string | null;
    avatarUrl: string | null;
    uid: string | null;
}
export interface LoginPanelState {
    status: 'idle' | 'pending' | 'success' | 'error';
    message: string;
    lastError: string | null;
    hasCookie: boolean;
    cookieStatusText: string;
    autoLoginEnabled: boolean;
    qrImageDataUrl: string | null;
    cookieFile: string;
    lastQrUpdatedAt: number | null;
    lastCookieRefreshAt: number | null;
    loginUrl: string;
    profile: WeiboProfile | null;
}
export declare const requestAccountApi: <T>(path: string, init?: RequestInit) => Promise<T>;
