type AnyCookie = any;
export interface CookieResult {
    cookieString: string;
    cookies: AnyCookie[];
    qrImageDataUrl?: string;
    qrDetected?: boolean;
}
export declare function saveCookiesToDatabase(ctx: any, cookies: AnyCookie[]): Promise<void>;
export declare function loadCookiesFromDatabase(ctx: any): Promise<AnyCookie[] | null>;
export declare function loadCookieStringFromDatabase(ctx: any): Promise<string | null>;
export interface QrLoginOptions {
    timeoutMs?: number;
    onPageCreated?: (page: any) => void | Promise<void>;
    onQrCaptured?: (dataUrl: string | null) => void | Promise<void>;
}
export declare function captureQrFromPage(page: any, timeoutMs?: number): Promise<{
    dataUrl: string | null;
    detected: boolean;
}>;
export declare function loginWithQrViaService(ctx: any, opts?: QrLoginOptions): Promise<CookieResult>;
/**
 * 静默打开微博主页，利用已有的 Cookie 自动续期
 */
export declare function renewCookiesViaService(ctx: any, existingCookies: AnyCookie[]): Promise<CookieResult>;
export {};
