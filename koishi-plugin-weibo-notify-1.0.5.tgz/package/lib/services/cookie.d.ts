export declare function setCookie(cookie: string | null): void;
export declare function getCookie(): string | null;
export declare function setUserAgent(userAgent: string | null): void;
export declare function getUserAgent(): string | null;
export declare function getRandomUserAgent(): string;
export declare function setCookieUpdater(updater: (() => Promise<string | null>) | null): void;
export declare function extractXSRFToken(cookie: string | null): string;
export declare function fetchCookie(): Promise<string>;
export declare function refreshCookie(): Promise<string | null>;
